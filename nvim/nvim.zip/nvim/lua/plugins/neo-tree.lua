return {
  "nvim-neo-tree/neo-tree.nvim",
  opts = {
    filesystem = {
      filtered_items = {
        visible = false, -- default hidden state
        show_hidden_count = true,
        hide_dotfiles = false, -- show dotfiles
        hide_gitignored = false, -- show gitignored files
        hide_by_name = {
          "node_modules",
          "thumbs.db",
        },
        never_show = {
          ".git",
          ".DS_Store",
        },
      },
    },
  },
}
