return {
  {
    "AstroNvim/astrocore",
    opts = {
      options = {
        opt = {
          relativenumber = false, -- disable relative numbering
          number = true,          -- keep absolute numbering
        },
      },
    },
  },
}
